package com.omelan.cofi.share.utils

const val verify_cofi_phone_app = "verify_cofi_phone_app"
const val verify_cofi_wear_app = "verify_cofi_wear_app"
