package com.omelan.cofi.ui

import androidx.compose.material3.Shapes

val shapes = Shapes()
